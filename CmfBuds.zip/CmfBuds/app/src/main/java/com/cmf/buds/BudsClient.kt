package com.cmf.buds

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.UUID

data class Dev(val name: String, val device: BluetoothDevice)

data class BudsState(
    val connected: Boolean = false,
    val status: String = "Не подключено",
    val name: String = "",
    val left: Int = -1,
    val right: Int = -1,
    val case: Int = -1,
    val anc: Int = 5,
    val spatial: Boolean = false,
    val lowLatency: Boolean = false,
    val bassOn: Boolean = false,
    val bassLevel: Int = 1,
    val log: List<String> = emptyList()
)

/**
 * Протокол Nothing/CMF поверх Bluetooth RFCOMM (UUID aeac4a03-...).
 * Кадр: 55 60 01 | cmd(2, LE) | len(2, LE) | seq | payload | CRC16-Modbus (LE)
 */
@SuppressLint("MissingPermission")
class BudsClient(ctx: Context) {
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(BudsState())
    val state: StateFlow<BudsState> = _state
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null
    private var seq = 0x20
    private val uuid = UUID.fromString("aeac4a03-dff5-498f-843a-34487cf133eb")

    fun bonded(): List<Dev> =
        adapter?.bondedDevices.orEmpty()
            .map { Dev(it.name ?: it.address, it) }
            .sortedByDescending { it.name.contains("CMF", true) || it.name.contains("Nothing", true) }

    fun connect(d: Dev) {
        scope.launch {
            close()
            _state.update { it.copy(status = "Подключение…", name = d.name) }
            adapter?.cancelDiscovery()
            val s = open(d.device)
            if (s == null) {
                _state.update { it.copy(status = "Не удалось открыть канал управления (наушники должны быть подключены к телефону)") }
                return@launch
            }
            socket = s
            out = s.outputStream
            _state.update { it.copy(connected = true, status = "Подключено") }
            requestAll()
            try { readLoop(s) } catch (e: Exception) { log("read: ${e.message}") }
            _state.update { it.copy(connected = false, status = "Соединение потеряно") }
        }
    }

    private fun open(dev: BluetoothDevice): BluetoothSocket? {
        try {
            val s = dev.createRfcommSocketToServiceRecord(uuid)
            s.connect()
            return s
        } catch (e: Exception) { log("SDP: ${e.message}") }
        for (ch in intArrayOf(16, 15)) {
            try {
                val m = dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                val s = m.invoke(dev, ch) as BluetoothSocket
                s.connect()
                return s
            } catch (e: Exception) { log("канал $ch: ${e.message}") }
        }
        return null
    }

    private fun readLoop(s: BluetoothSocket) {
        val inp = s.inputStream
        val tmp = ByteArray(1024)
        var buf = ByteArray(0)
        while (true) {
            val n = inp.read(tmp)
            if (n < 0) break
            buf += tmp.copyOf(n)
            while (true) {
                val i = buf.indexOf(0x55.toByte())
                if (i < 0) { buf = ByteArray(0); break }
                if (i > 0) buf = buf.copyOfRange(i, buf.size)
                if (buf.size < 10) break
                val len = (buf[5].toInt() and 0xFF) or ((buf[6].toInt() and 0xFF) shl 8)
                if (len > 512) { buf = buf.copyOfRange(1, buf.size); continue }
                val total = 10 + len
                if (buf.size < total) break
                val cmd = (buf[3].toInt() and 0xFF) or ((buf[4].toInt() and 0xFF) shl 8)
                handle(cmd, buf.copyOfRange(8, 8 + len))
                buf = buf.copyOfRange(total, buf.size)
            }
        }
    }

    private fun handle(cmd: Int, p: ByteArray) {
        log("← %04X %s".format(cmd, p.hex()))
        fun u(i: Int) = p[i].toInt() and 0xFF
        when (cmd) {
            0xE001, 0x4007 -> if (p.isNotEmpty()) {
                var l = _state.value.left
                var r = _state.value.right
                var c = _state.value.case
                for (k in 0 until u(0)) {
                    val j = 1 + 2 * k
                    if (j + 1 >= p.size) break
                    val v = u(j + 1) and 0x7F
                    when (u(j)) {
                        2 -> l = v
                        3 -> r = v
                        4 -> c = v
                    }
                }
                _state.update { it.copy(left = l, right = r, case = c) }
            }
            0xE003, 0x401E -> if (p.size >= 2) _state.update { it.copy(anc = u(1)) }
            0x4041 -> if (p.isNotEmpty()) _state.update { it.copy(lowLatency = u(0) == 1) }
            0x404E -> if (p.size >= 2) _state.update { it.copy(bassOn = u(0) == 1, bassLevel = (u(1) / 2).coerceIn(1, 5)) }
        }
    }

    private fun send(cmd: Int, payload: ByteArray = ByteArray(0)) {
        val o = out ?: return
        val b = ByteArrayOutputStream()
        b.write(0x55); b.write(0x60); b.write(0x01)
        b.write(cmd and 0xFF); b.write((cmd shr 8) and 0xFF)
        b.write(payload.size and 0xFF); b.write((payload.size shr 8) and 0xFF)
        seq = (seq + 1) and 0xFF
        b.write(seq)
        b.write(payload)
        val crc = crc16(b.toByteArray())
        b.write(crc and 0xFF); b.write((crc shr 8) and 0xFF)
        val bytes = b.toByteArray()
        scope.launch {
            try {
                synchronized(o) { o.write(bytes); o.flush() }
                log("→ %04X %s".format(cmd, payload.hex()))
            } catch (e: Exception) { log("send: ${e.message}") }
        }
    }

    private fun crc16(d: ByteArray): Int {
        var c = 0xFFFF
        for (x in d) {
            c = c xor (x.toInt() and 0xFF)
            repeat(8) { c = if ((c and 1) != 0) (c shr 1) xor 0xA001 else c shr 1 }
        }
        return c
    }

    private fun ByteArray.hex() = joinToString(" ") { "%02X".format(it) }
    private fun log(s: String) = _state.update { it.copy(log = (it.log + s).takeLast(40)) }
    private fun b(v: Boolean, a: Int, c: Int) = (if (v) a else c).toByte()

    fun requestAll() { send(0xC007); send(0xC01E); send(0xC041); send(0xC04E) }

    /** 1 высокое, 2 среднее, 3 низкое, 4 адаптивное, 5 выкл, 7 прозрачность */
    fun setAnc(code: Int) {
        send(0xF00F, byteArrayOf(1, code.toByte(), 0))
        _state.update { it.copy(anc = code) }
    }

    fun setSpatial(on: Boolean) {
        send(0xF052, byteArrayOf(b(on, 1, 0), 0))
        _state.update { it.copy(spatial = on) }
    }

    fun setLowLatency(on: Boolean) {
        send(0xF040, byteArrayOf(b(on, 1, 2), 0))
        _state.update { it.copy(lowLatency = on) }
    }

    fun setBass(on: Boolean, level: Int) {
        send(0xF051, byteArrayOf(b(on, 1, 0), (level * 2).toByte()))
        _state.update { it.copy(bassOn = on, bassLevel = level) }
    }

    fun disconnect() {
        scope.launch { close() }
        _state.update { it.copy(connected = false, status = "Не подключено") }
    }

    private fun close() {
        try { socket?.close() } catch (e: Exception) { }
        socket = null
        out = null
    }
}
