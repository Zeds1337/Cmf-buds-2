package com.cmf.buds

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private var granted by mutableStateOf(false)
    private val req = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val client = BudsClient(applicationContext)
        granted = Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        if (!granted) req.launch(Manifest.permission.BLUETOOTH_CONNECT)
        setContent { App(client, granted) }
    }
}

private val PanelBg = Color(0xFF1C1C1C)

@Composable
fun App(c: BudsClient, granted: Boolean) {
    val st by c.state.collectAsState()
    var devs by remember { mutableStateOf(emptyList<Dev>()) }
    LaunchedEffect(granted) { if (granted) devs = c.bonded() }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(
            Modifier.fillMaxSize().background(Color.Black)
                .statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Устройства", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Medium)
            if (!st.connected) {
                Text(st.status, color = Color.Gray)
                if (!granted) Text("Разрешите «Устройства поблизости» и нажмите «Обновить»", color = Color.Gray)
                devs.forEach { d ->
                    Button(onClick = { c.connect(d) }, modifier = Modifier.fillMaxWidth()) { Text(d.name) }
                }
                OutlinedButton(onClick = { devs = c.bonded() }) { Text("Обновить список") }
            } else {
                Text(
                    st.name, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Batt("L", st.left); Batt("R", st.right); Batt("Кейс", st.case)
                }
                Panel("Шумоподавление") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ModeBtn("Шумоподавл.", "◉", st.anc in 1..4) { c.setAnc(if (st.anc in 1..4) st.anc else 1) }
                        ModeBtn("Прозрачность", "◌", st.anc == 7) { c.setAnc(7) }
                        ModeBtn("Выкл.", "⊘", st.anc == 5) { c.setAnc(5) }
                    }
                    if (st.anc in 1..4) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(1 to "Высокое", 2 to "Среднее", 3 to "Низкое", 4 to "Адапт.").forEach { (k, n) ->
                                Pill(n, st.anc == k) { c.setAnc(k) }
                            }
                        }
                    }
                }
                Panel("Пространственный звук") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ModeBtn("Фиксированная", "◍", st.spatial) { c.setSpatial(true) }
                        ModeBtn("Выкл.", "◖◗", !st.spatial) { c.setSpatial(false) }
                    }
                }
                Panel("Ultra Bass") {
                    Row(
                        Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (st.bassOn) "Вкл · Уровень ${st.bassLevel}" else "Выкл.", color = Color.Gray)
                        Switch(checked = st.bassOn, onCheckedChange = { c.setBass(it, st.bassLevel) })
                    }
                    if (st.bassOn) {
                        Slider(
                            value = st.bassLevel.toFloat(), valueRange = 1f..5f, steps = 3,
                            onValueChange = { c.setBass(true, it.toInt().coerceIn(1, 5)) }
                        )
                    }
                }
                Panel("Режим малой задержки") {
                    Row(
                        Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (st.lowLatency) "Вкл." else "Выкл.", color = Color.Gray)
                        Switch(checked = st.lowLatency, onCheckedChange = { c.setLowLatency(it) })
                    }
                }
                Panel("Журнал (отладка)") {
                    st.log.takeLast(10).forEach {
                        Text(it, color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
                OutlinedButton(onClick = { c.disconnect() }, modifier = Modifier.fillMaxWidth()) { Text("Отключиться") }
            }
        }
    }
}

@Composable
fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(PanelBg).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        content()
    }
}

@Composable
fun ModeBtn(label: String, sym: String, sel: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(if (sel) Color(0xFFEFEFEF) else Color(0xFF2C2C2C)),
            contentAlignment = Alignment.Center
        ) { Text(sym, fontSize = 28.sp, color = if (sel) Color.Black else Color.White) }
        Spacer(Modifier.height(8.dp))
        Text(label, color = if (sel) Color.White else Color.Gray, fontSize = 14.sp)
    }
}

@Composable
fun Pill(text: String, sel: Boolean, onClick: () -> Unit) {
    Text(
        text, color = if (sel) Color.Black else Color.White, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) Color(0xFFEFEFEF) else Color(0xFF2C2C2C))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
fun Batt(label: String, v: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.width(60.dp).height(3.dp).background(Color.White))
        Spacer(Modifier.height(6.dp))
        Text("$label ${if (v >= 0) "$v%" else "—"}", color = Color.White, fontSize = 16.sp)
    }
}
